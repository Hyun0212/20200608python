class Main {
  public static void main(String[] args) {
    System.out.println("Hello world!");
    int sum=0;
    for(int i=1;i<11;i++){
    System.out.printf("%d  ",i);
    sum+=i;
  }
  System.out.printf("\t %d  ",sum);
  }
}