#include <stdio.h>

int main() {

  int i, sum=0;
  for(i=1; i<11; i++)
  {
    printf("%d ",i);
    sum+=i;
  }
  printf("\t%d",sum);
  return 0;
}